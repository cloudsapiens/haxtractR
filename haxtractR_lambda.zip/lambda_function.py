#############################################################################################################################
# haxtractR - https://github.com/cloudsapiens/haxtractR
# Created on 10/19/2020
# An AWS Lambda function written in Python to extract data from SAP HANA database storing credentials in AWS Secrets Manager
#############################################################################################################################

import pyhdb
import os
import json
import logging
import boto3
import base64
from botocore.exceptions import ClientError

logger = logging.getLogger()
logger.setLevel(logging.DEBUG)

#############################################################################################################################
# Function to retrieve secret from AWS Secrets Manager using boto3 library and handling the exceptions. The secrets variable
# will be used to give deliver the retrieved secrets DB_USER and DB_PASSWORD.
#############################################################################################################################

def get_secret():
#############################################################################################################################  
# Adjust the values
    secret_name = "hana-credentials"
    region_name = "us-east-1"
#############################################################################################################################

    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )
    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as e:
        if e.response['Error']['Code'] == 'DecryptionFailureException':
            raise e
        elif e.response['Error']['Code'] == 'InternalServiceErrorException':
            raise e
        elif e.response['Error']['Code'] == 'InvalidParameterException':
            raise e
        elif e.response['Error']['Code'] == 'InvalidRequestException':
            raise e
        elif e.response['Error']['Code'] == 'ResourceNotFoundException':
            raise e
    else:
        if 'SecretString' in get_secret_value_response:
            secret = get_secret_value_response['SecretString']
        else:
            decoded_binary_secret = base64.b64decode(get_secret_value_response['SecretBinary'])
    secrets = json.loads(secret)
    return secrets

#############################################################################################################################
# Function to connect to SAP Hana database using pyHDB library and the credentials from AWS Secrets Manager. 
# SQL_STATEMENT environment variable contains the SQL statement, which will be executed on database layer and giving back to 
# stringified result in variable sql_result and closes the connection.
#############################################################################################################################

def connect_to_hana():
    get_secrets = get_secret()
    db_user = json.dumps(get_secrets['DB_USER']).replace('"', '')
    db_password = json.dumps(get_secrets['DB_PASSWORD']).replace('"', '')
    connect = pyhdb.connect(os.environ["DB_HOST"], os.environ["DB_PORT"], db_user, db_password) 
    cursor = connect.cursor()
    cursor.execute(os.environ["SQL_STATEMENT"])
    sql_result = str(json.dumps(cursor.fetchall()).replace("[", "").replace("]", "").replace('"', ''))
    return sql_result
    connect.close()

#############################################################################################################################
# Lambda handler
#############################################################################################################################

def lambda_handler(event, context):
    return connect_to_hana(event)





